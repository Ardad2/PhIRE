Cross-toolkit closeout bundle

Run in this order:

1) Phase A W22 parity closeout
2) Phase D frozen-cohort consistency closeout
3) Three-way W22 analysis

Install:
  cd ~/PhIRE
  install -m 755 scripts/phaseA_closeout_w22_adapter.py "$W22/phaseA_closeout_w22_adapter.py"
  install -m 755 scripts/phaseD_closeout_cohorts.py "$W22/phaseD_closeout_cohorts.py"
  install -m 755 scripts/three_way_w22_analysis.py "$W22/three_way_w22_analysis.py"

Environment:
  GUDHI_PY="$HOME/micromamba/envs/gudhi-audit/bin/python"
  TOOLKIT_ROOT="$HOME/PhIRE/third_party/tda-toolkit-mapper"

Phase A:
  PYTHONNOUSERSITE=1 "$GUDHI_PY" "$W22/phaseA_closeout_w22_adapter.py" \
    --toolkit-root "$TOOLKIT_ROOT" 2>&1 | tee "$W22/phaseA_closeout_w22_adapter.log"

Phase D:
  PYTHONNOUSERSITE=1 "$GUDHI_PY" "$W22/phaseD_closeout_cohorts.py" \
    2>&1 | tee "$W22/phaseD_closeout_cohorts.log"

Three-way:
  PYTHONNOUSERSITE=1 "$GUDHI_PY" "$W22/three_way_w22_analysis.py" \
    2>&1 | tee "$W22/three_way_w22_analysis.log"

Then paste:
  cat "$W22/pd_colleague_compatibility/phaseA_w22_closeout/phaseA_colleague_adapter_W22_parity_summary.txt"
  cat "$W22/pd_colleague_compatibility/phaseD_closeout/phaseD_cohort_consistency_summary.txt"
  cat "$W22/pd_colleague_compatibility/three_way_w22/three_way_w22_summary.txt"

The optional patch is not needed for the audit. It is only a proposed backward-compatible API extension to discuss with the colleague.
