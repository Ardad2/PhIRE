# Phase 6 — CV-only completed: verified evaluation and quantitative comparison

**Record date:** October 13, 2026

The following is the append-only master-notes Part LXX entry; it supersedes the *pending-evaluation status* of Part LXIX without rewriting the historical observations.


---

# Part LXX — Phase 6 CV-only model: verified training, scalar/domain results, 2×2 ablation interim comparison, and patch correction (October 13, 2026)

## LXX.1 Evidence and status (new observations, not speculative)

The researcher completed the **`grad_cv_only`** fine-tuning arm, with `Training pipeline exit status: 0`, followed by a successful independent scalar/domain evaluation (`Evaluation exit status: 0`). The network was fine-tuned from the original pretrained PhIRE CNN, retaining `L_uv=1`, `L_grad=0.05`, adding only the **fixed-index critical-value** loss `L_TTKCV=0.004` and disabling the fixed-pair persistence-gap loss `L_TTKpers=0`. The prior static tests also showed no unintended auxiliary losses. This is a **CNN fine-tuning ablation, not a new SR architecture**.

Experiment identifier: `candidateF_grad_CV_only_expanded2688`.

- Training set: `example_data_topology_expanded_2688/wind_MR-HR.tfrecord` (**2,688** fields, three training epochs); fixed held-out evaluation: `example_data_fixed/wind_MR-HR.tfrecord` (**168** fields).
- Checkpoints: `models_fixed/topology_finetuning/wind_finetune_candidateF_grad_CV_only_expanded2688/cnn00001/cnn`, `cnn00002/cnn`, `cnn00003/cnn`, plus final `cnn/cnn`. All three epoch checkpoints and the final checkpoint were reported.
- Outputs: `data_out/wind_finetune_candidateF_grad_CV_only_expanded2688/idx.npy` shape `(168,)`; `dataIN.npy` shape `(168,100,100,2)`; `dataGT.npy` and `dataSR.npy` each shape `(168,500,500,2)`. All arrays passed shape/finiteness checks. Indices exactly `0..167`.
- **Exact paired benchmark validation:** candidate `dataGT.npy` and `dataIN.npy` matched `data_out_fixed/wind_mrhr_cnn/` via `np.array_equal=True`, with maximum absolute difference `0.0000e+00`.
- GT vector ranges: `u=[-16.1737,30.8122]`, `v=[-30.4676,28.1310]`; CV-only SR vector ranges: `u=[-16.8503,29.5821]`, `v=[-29.7248,28.4144]`.
- GT scalar-speed range: `[0.0122,33.9885] m/s`; CV-only SR range: `[0.0010,39.3331] m/s`. CV-only SR's maximum is **5.3446 m/s (~15.7%) above** this benchmark GT maximum. This passed the training runner's nonfatal plausibility reporting, but **extreme-value overshoot deserves targeted per-field examination** before treating this as unqualified physical improvement. A reconstructed maximum may legitimately exceed the dataset's maximum; this alone does not prove a nonphysical prediction.
- CV-only speed MAE: `0.5714 m/s` (more precisely see the generated metric CSV); evaluation wrote **672 rows = 4 methods × 168 samples** for bicubic, CNN, GAN and CV-only.
- SSIM **not computed** (`skimage` NumPy binary incompatibility, `Expected 96 from C header, got 88 from PyObject`). SSIM `NaN` and pairwise `0/0` valid comparisons are **missing data**, not zero-valued results. Preserve this limitation; do not mix in SSIM from a different convention without reproducing the same metric.
- The pre-existing topology CSV supplied **336 lookup entries** for CNN and GAN; **no new candidate CV-only PD bottleneck, corrected W₂, merge-tree, or spatially constrained matching values** have been computed.

Primary new numerical source (generated on Spark and supplied by author):

`docs/topology_finetuning_candidateF_grad_CV_only_expanded2688_eval.md`

Additional output artifacts:

```text
logs/wind_finetune_candidateF_grad_CV_only_expanded2688.log
logs/phase6_grad_cv_only_console.log
logs/phase6_candidateF_grad_CV_only_expanded2688_cheap_eval.log
ttk_runs_fixed/topology_finetuning/candidateF_grad_CV_only_expanded2688_eval/
  all_sample_metrics_candidateF_grad_CV_only_expanded2688.csv
  pairwise_cnn_vs_candidateF_grad_CV_only_expanded2688.csv
  winner_counts_candidateF_grad_CV_only_expanded2688.csv
  adjacent_cluster_table_candidateF_grad_CV_only_expanded2688.csv
models_fixed/topology_finetuning/wind_finetune_candidateF_grad_CV_only_expanded2688/cnn/cnn.*
```

## LXX.2 Matched scalar/domain comparison (same 168-field benchmark)

The table compares the new uploaded CV-only report and the prior uploaded gradient-only report with the frozen archived `docs/topology_finetuning_candidateF_grad_E2_low_expanded2688_eval.md` (historical full F1). The first three columns' numbers are from current eval reports; F1 is rounded to four decimals as in its archived evaluation report. **↑ means higher is better; ↓ means lower is better.** Columns are per-field means, not standard errors.

| Metric | CNN | Grad-only | Grad + CV | Grad + CV + PERS (F1) |
|---|---:|---:|---:|---:|
| PSNRuv (dB) ↑ | 31.1925 | 33.3872 | 32.7620 | 32.4949 |
| Speed MAE (m/s) ↓ | 0.6941 | 0.5275 | 0.5714 | 0.5899 |
| Speed RMSE (m/s) ↓ | 1.1078 | 0.8939 | 0.9592 | 0.9891 |
| WPD MAE (m³/s³) ↓ | 231.6709 | 169.3772 | 184.5553 | 190.6897 |
| WPD Wasserstein-1 ↓ | 45.2713 | 22.3588 | 22.6663 | 24.7322 |
| WPD bias abs (m³/s³) ↓ | 35.3439 | 16.4208 | 20.6194 | 22.6377 |
| Gradient MAE ↓ | 0.3491 | 0.3107 | 0.3111 | 0.3125 |
| Gradient W1 ↓ | 0.2329 | 0.1809 | 0.1494 | 0.1381 |
| Gradient kurtosis abs Δ ↓ | 3.7004 | 2.5295 | 3.1057 | 3.2601 |
| PSD log-L2 ↓ | 0.8335 | 0.8992 | 0.8433 | 0.8147 |
| PSD slope abs Δ ↓ | 0.9150 | 1.4924 | 1.3487 | 1.1385 |
| Exceedance abs Δ s>5 ↓ | 0.0042 | 0.0039 | 0.0022 | 0.0025 |
| Exceedance abs Δ s>10 ↓ | 0.0066 | 0.0032 | 0.0052 | 0.0052 |
| Exceedance abs Δ s>15 ↓ | 0.0062 | 0.0030 | 0.0025 | 0.0027 |
| Exceedance abs Δ p90 ↓ | 0.0103 | 0.0040 | 0.0039 | 0.0047 |
| Component-count curve L1 ↓ | 115.5278 | 97.6548 | 77.8165 | 81.1815 |

Useful **CV-only versus gradient-only** mean differences (CV minus grad-only; from rounded report values):

| Metric | CV − gradient-only | Interpretation |
|---|---:|---|
| PSNRuv (dB) | −0.6252 | Worse reconstruction PSNR |
| Speed MAE (m/s) | +0.0439 | Worse mean scalar-speed error |
| Speed RMSE (m/s) | +0.0653 | Worse mean scalar-speed error |
| WPD MAE | +15.1781 | Worse magnitude-proxy error |
| Gradient W1 | −0.0315 | Better gradient-distribution agreement |
| Component-count curve L1 | −19.8383 | Better superlevel component-count proxy |
| PSD log-L2 | −0.0559 | Better than gradient-only, but still worse than original CNN |
| PSD slope abs delta | −0.1437 | Better than gradient-only, but still worse than original CNN |

**CV-only vs F1:** CV-only has *better* PSNRuv (`32.7620` vs `32.4949`), scalar-speed MAE (`0.5714` vs `0.5899`) and component-count curve L1 (`77.8165` vs `81.1815`); F1 is *better* for gradient W1 (`0.1381` vs `0.1494`), PSD log-L2 (`0.8147` vs `0.8433`), and PSD slope error (`1.1385` vs `1.3487`). These are **descriptive aggregate comparisons**, not formal per-sample paired win counts and not proof that CV-only has lower PD/MT distances.

**CV-only vs pretrained CNN (168 fields):** PSNRuv `32.7620` vs `31.1925` (higher on `168/168`); scalar-speed MAE `0.5714` vs `0.6941` (lower on `168/168`); component-count L1 `77.8165` vs `115.5278` (lower on `162/168`). In contrast, PSD slope error `1.3487` vs `0.9150` is worse on **168/168** samples. These counts are from the CV-only report's *comparisons against CNN*, not direct CV-versus-gradient-only comparisons.

**Scientific interpretation:** CV supervision appears to exchange part of gradient-only's direct-fidelity advantage for improved **selected** topology-adjacent proxies (component counts) and gradient-distribution agreement. However, the original F1 and CV-only models also differ across metrics in different directions. True persistence/merge-tree and locality comparisons, plus the matched PERS-only training arm, are required to assess the specific CV/PERS contributions. The 168 hourly fields are temporally correlated and these are single runs per arm (no seed-replicate inference).

## LXX.3 Exact terminal procedure used for CV-only evaluation

```bash
cd ~/PhIRE
mkdir -p logs
set -o pipefail
METHOD=candidateF_grad_CV_only_expanded2688

env -u PYTHONNOUSERSITE /usr/bin/python3 \
  scripts/evaluate_finetune_candidate.py \
  --candidate-name "$METHOD" \
  --candidate-dir "data_out/wind_finetune_${METHOD}" \
  --cnn-dir data_out_fixed/wind_mrhr_cnn \
  --gan-dir data_out_fixed/wind_mrhr_gan \
  --merged-csv ttk_runs_fixed/combined/psnr_topology_physics_merged.csv \
  --out-dir "ttk_runs_fixed/topology_finetuning/${METHOD}_eval" \
  2>&1 | tee "logs/phase6_${METHOD}_cheap_eval.log"
echo "Evaluation exit status: $?"
```

Observed concluding output:

```text
  Common samples: 168
  Checking GT alignment … OK (max_abs_diff=0.00e+00)
  Topology lookup loaded: 336 entries
  Total metric rows: 672
  Written: docs/topology_finetuning_candidateF_grad_CV_only_expanded2688_eval.md
  Evaluation complete.
  Evaluation exit status: 0
```

A supplementary standard-library-only report comparator is included at `scripts/compare_phase6_cheap_reports.py` **in the accompanying documentation package**. It reads the three Markdown reports without importing NumPy/pandas/TF. The code is not automatically installed to the Spark repository; copy it deliberately if useful. Comparisons of paired *per-field* candidate deltas require the generated `all_sample_metrics_*.csv` files, which have **not been supplied in this chat**. Do not invent per-field CV-versus-gradient-only counts.

## LXX.4 Git patch failure, diagnosis, and non-destructive recovery

The user's local repository-root `dataset_generation_and_repair_notes.md` showed Part `LXVII` as the most recently applied heading. The package `Phase6_CV_Only_Training_Notes_LXIX_20261013.zip` included mutually exclusive transition patches, but the author attempted the `LXVIII_to_LXIX` patch:

```text
error: patch failed: dataset_generation_and_repair_notes.md:37531
error: dataset_generation_and_repair_notes.md: patch does not apply
```

The wrong starting revision caused a missing context block; `git apply --check` is non-mutating and the failed plain `git apply` also rejected the patch, so **the prior notes remain intact**. The correct old package patch would have been `phase6_grad_cv_only_LXVII_to_LXIX.patch`. However, because complete CV-only results are now available, prefer the **single cumulative `LXVII_to_LXX` patch** in the newer documentation package. It adds missing LXVIII, LXIX, and the present LXX in one operation. Other cumulative patches from LXVIII and LXIX are also provided only for alternative starting versions. Never apply more than one.

Example check on Spark (after transferring/unzipping new package):

```bash
cd ~/PhIRE
PATCH=phase6_cv_eval_docs/patches/phase6_notes_LXVII_to_LXX.patch
git apply --check "$PATCH" && git apply "$PATCH"
grep '^# Part LX' dataset_generation_and_repair_notes.md | tail -6
git diff --stat -- dataset_generation_and_repair_notes.md
```

If `git apply --check` fails, do **not** use `git apply --reject`, `git reset --hard`, or overwrite the master file with a provided full file; inspect the local difference first. Keep `master`'s unrelated figure changes and the immutable `topoinvis-2026-arxiv-v1.1` release unchanged.

## LXX.5 Next Phase 6 arm and deferred topology work

The remaining PERS-only variant is `grad_pers_only`, method `candidateF_grad_PERS_only_expanded2688`, objective `L_uv + 0.05 L_grad + 0.002 L_TTKpers` (CV weight zero). It uses the same 2,688-sample training TFRecord, 168-sample fixed benchmark and repaired 64-pair-per-training-sample E2 constraints. Its dry-run was validated in Part LXV but a **real PERS-only run is not yet reported**. After running, first validate saved checkpoints, exact GT/IN alignment, and scalar-speed range, then run the matching cheap evaluation.

```bash
cd ~/PhIRE
mkdir -p logs
tmux new -s phase6_pers_only
# Inside tmux:
set -o pipefail
env -u PYTHONNOUSERSITE /usr/bin/python3 \
  scripts/run_candidateF_cv_pers_ablation.py --variant grad_pers_only \
  2>&1 | tee logs/phase6_grad_pers_only_console.log
printf 'Training pipeline exit status: %s\n' "$?"
```

Keep the completed CNN, gradient-only, CV-only and full-F1 checkpoints/arrays immutable; train one variant at a time. No expensive TTK recomputation has been performed for the new two arms. After PERS-only cheap evaluation, run **matched, corrected** PD bottleneck/W₂ and merge-tree measures and, especially for the geospatial research direction, the same locality-constrained PD matching across all four arms. Consider comparing extreme overshoots and negative PSD deviations alongside pointwise and topology scores.

**Scientific status as of the supplied evidence:** Two of three new Phase 6 arms trained and cheap-evaluated; PERS-only training and all new-arm corrected PD/MT/spatial evaluations remain pending.
